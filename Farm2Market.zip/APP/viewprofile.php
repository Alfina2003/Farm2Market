<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Farmer Information</title>
    <style>
        body {
    		font-family: Arial, sans-serif;
    		background-color: #076f76;
            	background-size: cover;
      		position: relative;
    		margin: 0;
    		padding: 0;
	}

        .container {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        input[type="text"], input[type="password"], select {
            width: calc(100% - 16px); /* Adjusted width to accommodate padding and border */
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Farmer Information</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Mobile Number</th>
                    <th>Address</th>
                    <th>Password</th>
                    <th>Type of Seller</th>
                    <th>Radius</th>
                </tr>
               <?php
session_start();

// Check if farmer is logged in
if (!isset($_SESSION['farmer_id'])) {
    // Redirect or display an error message if not logged in
    header("Location: login.php");
    exit();
}

// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "harshe23673065";
$dbname = "farm2market";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve edited field values
    $id = $_POST['id'];
    $name = $_POST['name'];
    $mobile_number = $_POST['mobile_number'];
    $address = $_POST['address'];
    $password = $_POST['password'];
    $type_of_seller = $_POST['type_of_seller'];
    $radius = $_POST['radius'];

    // Update farmer information in the database
    $sql = "UPDATE farmerregister SET name='$name', mobile_number='$mobile_number', address='$address', password='$password', type_of_seller='$type_of_seller', radius='$radius' WHERE id='$id'";
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Record updated successfully!'); window.location.href = 'viewprofile.php';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Fetch farmer information based on the logged-in farmer's ID
$farmer_id = $_SESSION['farmer_id'];
$sql = "SELECT * FROM farmerregister WHERE id='$farmer_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Display farmer information in a form
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["id"]."</td>";
        echo "<td><input type='text' name='name' value='".$row["name"]."'></td>";
        echo "<td><input type='text' name='mobile_number' value='".$row["mobile_number"]."'></td>";
        echo "<td><input type='text' name='address' value='".$row["address"]."'></td>";
        echo "<td><input type='password' name='password' value='".$row["password"]."'></td>";
        echo "<td><input type='text' name='type_of_seller' value='".$row["type_of_seller"]."'></td>";
        echo "<td><input type='text' name='radius' value='".$row["radius"]."'></td>";
        echo "<input type='hidden' name='id' value='".$row["id"]."'>"; // Hidden input field for farmer ID
        echo "</tr>";
    }
} else {
    echo "No farmer information found";
}

// Close connection
$conn->close();
?>
            </table>
            <input type="submit" name="submit" value="Submit">
        </form>
    </div>
</body>
</html>