<?php
// Assuming you have a database connection
$servername = "localhost";
$username = "root";
$password = "harshe23673065";
$dbname = "farm2market";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the product ID from the request
$product_id = $_GET['product_id'];

// Query to fetch product details
$sql = "SELECT * FROM addtoproduct WHERE id='$product_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Create an array containing product details
    $productDetails = array(
        'productname' => $row['productname'],
        'producttype' => $row['producttype'],
        'quantity' => $row['quantity'],
        'description' => $row['description'],
        'expiry_date' => $row['expiry_date'],
        'price' => $row['price']
    );
    // Encode the array to JSON and output
    echo json_encode($productDetails);
} else {
    echo "Product not found";
}

// Close connection
$conn->close();
?>
