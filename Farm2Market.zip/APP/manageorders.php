<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        .container {
            width: 50%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        select, input[type="submit"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
	   
        }
		
	input[type="submit"] {
	    background-color: #4CAF50;
            color: white;
	}

        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }

    </style>
</head>
<body>
    <div class="container">
        <h2>Select Order ID</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <label for="order_id">Order ID:</label>
            <select name="order_id" id="order_id">
                <?php
                    // Database connection parameters
                    $servername = "localhost";
                    $username = "root";
                    $password = "harshe23673065";
                    $dbname = "farm2market";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Fetch order IDs from the database
                    $sql = "SELECT id FROM orders";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<option value='".$row["id"]."'>".$row["id"]."</option>";
                        }
                    } else {
                        echo "<option value=''>No orders found</option>";
                    }

                    // Close connection
                    $conn->close();
                ?>
            </select>
            <input type="submit" name="submit" value="Submit">
        </form>

        <?php
            // Handle form submission
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Retrieve selected order ID
                $selected_order_id = $_POST['order_id'];

                if(!empty($selected_order_id)) {
                    // Fetch order details from the database based on the selected order ID
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $sql = "SELECT * FROM orders WHERE id = $selected_order_id";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Display order details in a table
                        echo "<h2>Order Details</h2>";
                        echo "<form method='post' action=''>";
                        echo "<table>";
                        while($row = $result->fetch_assoc()) {
                            echo "<tr><td>Customer ID</td><td>".$row["consumerid"]."</td></tr>";
                            echo "<tr><td>Order Date</td><td>".$row["order_date"]."</td></tr>";
                            echo "<tr><td>Total Amount</td><td>".$row["total_amount"]."</td></tr>";
                            echo "<tr><td>Order Status</td><td>";
                            echo "<select name='order_status'>";
                            echo "<option value='Pending'".($row['order_status'] == 'Pending' ? ' selected' : '').">Pending</option>";
                            echo "<option value='Delivered'".($row['order_status'] == 'Delivered' ? ' selected' : '').">Delivered</option>";
                            echo "</select></td></tr>";
                            echo "<tr><td>Delivery Address</td><td>".$row["delivery_address"]."</td></tr>";
                            echo "<tr><td>Contact Number</td><td>".$row["contact_number"]."</td></tr>";
                            echo "<tr><td>Special Instructions</td><td>".$row["special_instructions"]."</td></tr>";
                        }
                        echo "</table>";
                        echo "<input type='hidden' name='order_id' value='$selected_order_id'>";
                        echo "<input type='submit' name='update' value='Update'>";
                        echo "</form>";
                    } else {
                        echo "No order details found for Order ID: " . $selected_order_id;
                    }
                    $conn->close();
                } else {
                    echo "Please select an order ID";
                }
            }

            // Handle update form submission
            if (isset($_POST['update'])) {
                // Retrieve selected order ID and updated order status
                $selected_order_id = $_POST['order_id'];
                $order_status = $_POST['order_status'];

                if(!empty($selected_order_id)) {
                    // Update order status in the database based on the selected order ID
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $sql = "UPDATE orders SET order_status = '$order_status' WHERE id = $selected_order_id";
                    if ($conn->query($sql) === TRUE) {
                        echo "<script>alert('Order status updated successfully!'); window.location.href = 'manageorders.php';</script>";
                    } else {
                        echo "Error updating order status: " . $conn->error;
                    }

                    $conn->close();
                } else {
                    echo "Please select an order ID";
                }
            }
        ?>
    </div>
</body>
</html>
