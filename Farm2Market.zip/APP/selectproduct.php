<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farm2Market - Home</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
	    background-image: url('bg8.jpg');
    background-repeat: no-repeat; /* Set background repeat to no-repeat */
    background-size: cover; 

        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            margin-top: 50px;
            border-radius: 5px;
        }

        .form-group {
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .form-group select,
        .form-group button {
            padding: 8px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ccc;
            background-color: white;
            cursor: pointer;
        }

        .form-group select {
            width: 70%;
            border-radius: 5px 0 0 5px;
        }

        .form-group button {
            width: 15%;
            background-color: #4caf50;
            color: white;
        }

        .products {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            grid-gap: 20px;
            margin-top: 20px;
        }

        .product {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
        }

        .product-details span {
            font-weight: bold;
        }

        .add-to-cart {
            display: block;
            width: 100%;
            padding: 8px;
            margin-top: 10px;
            background-color: #4caf50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-align: center;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Farm2Market</h1>

        <div class="form-group">
            <select id="product-type">
                <option value="vegetable">Vegetable</option>
                <option value="fruit">Fruit</option>
            </select>
            <button onclick="searchProduct()">Search</button>
	    <button onclick="goToCart()">Go to Cart</button>
        </div>

        <div class="products" id="product-details">
            <?php
		session_start(); // Start the session
            if (isset($_GET['type'])) {
                $servername = "localhost";
                $username = "root";
                $password = "harshe23673065";
                $dbname = "farm2market";

                $conn = new mysqli($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $searchType = $_GET['type'];
                $sql = "SELECT * FROM addtoproduct WHERE producttype='$searchType'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<div class='product'>";
			echo "<span>Product ID:</span> " . $row['id'] . "<br>";
                        echo "<span>Product Name:</span> " . $row['productname'] . "<br>";
                        echo "<span>Expiry Date:</span> " . $row['expiry_date'] . "<br>";
                        echo "<span>Price:</span> " . $row['price'] . "<br>";
                        echo "<form action='" . $_SERVER['PHP_SELF'] . "' method='post'>";
                        echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
                        echo "<input type='hidden' name='productname' value='" . $row['productname'] . "'>";
                        echo "<input type='hidden' name='expiry_date' value='" . $row['expiry_date'] . "'>";
                        echo "<input type='hidden' name='price' value='" . $row['price'] . "'>";
                        echo "<button type='submit' class='add-to-cart' name='add_to_cart'>Add to Cart</button>";
                        echo "</form>";
                        echo "</div>";
                    }
                } else {
                    echo "No products found for the selected type.";
                }

                $conn->close();
            }

            

// Check if the consumer is logged in
if (!isset($_SESSION['consumer_id'])) {
    // Redirect or display an error message if not logged in
    header("Location: login.php");
    exit();
}

// Check if the add to cart form is submitted
if (isset($_POST['add_to_cart'])) {
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "harshe23673065";
    $dbname = "farm2market";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get consumer ID from the session
    $consumer_id = $_SESSION['consumer_id'];

    // Get product details from the form submission
    $productid = $_POST['id'];
    $productname = $_POST['productname'];
    $expiry_date = $_POST['expiry_date'];
    $price = $_POST['price'];

    // Prepare and execute the SQL query to insert data into the addtocart table
    $sql = "INSERT INTO addtocart (consumerid, productid, productname, expiry_date, price) 
            VALUES ('$consumer_id', '$productid', '$productname', '$expiry_date', '$price')";

    if ($conn->query($sql) === TRUE) {
        echo "<p>Product added to cart successfully.</p>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
            ?>
        </div>
    </div>

    <script>
        function searchProduct() {
            var selectedType = document.getElementById("product-type").value;
            window.location.href = "<?php echo $_SERVER['PHP_SELF']; ?>?type=" + selectedType;
        }
    </script>
    <script>
        function goToCart() {
            window.location.href = "add2cart.php"; // Replace "cart.php" with the URL of your cart page
        }
    </script>

</body>

</html>
