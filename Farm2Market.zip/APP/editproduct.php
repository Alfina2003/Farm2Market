<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farm2Market - Edit Product</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Additional CSS styles specific to this page */
        body {
            font-family: Arial, sans-serif;
            background-image: url('bg1.jpg'); /* Replace 'your-background-image.jpg' with the path to your image */
    	    /* Prevent background from repeating */
            background-position: center;
            display: flex;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .product-container {
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            width: 50%;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            text-align: center;
        }
        .product-container h1 {
            margin-top: 0;
            font-size: 28px;
            color: #333;
        }
        .form-container {
            margin-top: 20px;
        }
        .form-container label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            text-align: left;
            color: #555;
        }
        .form-container input[type="text"],
        .form-container input[type="number"],
        .form-container textarea,
        .form-container input[type="date"],
        .form-container select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
	    margin-bottom: 10px; 
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .form-container textarea {
            resize: vertical;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 20px;
            transition: background-color 0.3s;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="product-container">
        <h1>Edit Product</h1>
        <div class="form-container">
            <form action="update_product.php" method="post" id="edit-product-form">
                <label for="product-list">Select Product:</label>
                <select id="product-list" name="product-list">
                    <!-- Populate dropdown with products fetched from database -->
                    <?php
                    // Assuming you have a database connection
                    $servername = "localhost";
                    $username = "root";
                    $password = "harshe23673065";
                    $dbname = "farm2market";

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Query to fetch products
                    $sql = "SELECT id, productname FROM addtoproduct";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        // Output data of each row
                        while($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row['id'] . "'>" . $row['productname'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No products found</option>";
                    }

                    // Close connection
                    $conn->close();
                    ?>
                </select>

                <label for="product-name">Product Name:</label>
                <input type="text" id="product-name" name="product-name" placeholder="Product Name" required>

                <label for="product-type">Product Type:</label>
                <input type="text" id="product-type" name="product-type" placeholder="Product Type" required>

                <label for="product-quantity">Product Quantity:</label>
                <input type="number" id="product-quantity" name="product-quantity" placeholder="Product Quantity" required>

                <label for="product-description">Description of Product:</label>
                <textarea id="product-description" name="product-description" rows="4" placeholder="Description" required></textarea>

                <label for="product-expiry">Expiry Date:</label>
                <input type="date" id="product-expiry" name="product-expiry" required>

                <label for="product-price">Price:</label>
                <input type="number" id="product-price" name="product-price" placeholder="Price" required>

                <button type="submit">Edit Product</button>
            </form>
        </div>
    </div>

    <script>
        // Function to fetch product details based on selected product
        function fetchProductDetails() {
            var productId = document.getElementById('product-list').value;
            if (productId !== '') {
                // AJAX call to fetch product details
                var xhr = new XMLHttpRequest();
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === XMLHttpRequest.DONE) {
                        if (xhr.status === 200) {
                            var productDetails = JSON.parse(xhr.responseText);
                            document.getElementById('product-name').value = productDetails.productname;
                            document.getElementById('product-type').value = productDetails.producttype;
                            document.getElementById('product-quantity').value = productDetails.quantity;
                            document.getElementById('product-description').value = productDetails.description;
                            document.getElementById('product-expiry').value = productDetails.expiry_date;
                            document.getElementById('product-price').value = productDetails.price;
                        } else {
                            console.log('Error fetching product details');
                        }
                    }
                };
                xhr.open('GET', 'get_product_details.php?product_id=' + productId, true);
                xhr.send();
            }
        }

        // Event listener for the dropdown change event
        document.getElementById('product-list').addEventListener('change', fetchProductDetails);
    </script>
</body>
</html>
