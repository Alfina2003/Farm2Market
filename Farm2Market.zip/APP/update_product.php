<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = "harshe23673065";
$dbname = "farm2market";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve form data
$product_id = $_POST['product-list'];
$product_name = $_POST['product-name'];
$product_type = $_POST['product-type'];
$product_quantity = $_POST['product-quantity'];
$product_description = $_POST['product-description'];
$product_expiry = $_POST['product-expiry'];
$product_price = $_POST['product-price'];

// Update product information in the database
$sql = "UPDATE addtoproduct SET productname='$product_name', producttype='$product_type', quantity='$product_quantity', description='$product_description', expiry_date='$product_expiry', price='$product_price' WHERE id='$product_id'";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Product edited successfully!'); window.location.href = 'mainframe.php';</script>";
        	    exit();
} else {
    echo "Error updating product: " . $conn->error;
}

// Close connection
$conn->close();
?>
