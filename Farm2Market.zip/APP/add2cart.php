<!DOCTYPE html>
<html>
<head>
    <title>Place Order</title>
     <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
	    background-image: url('bg3.jpg');
            min-height: 100vh;
        }
        .container {
            width: 50%;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        form {
            max-width: 600px;
            margin: 0 auto;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="number"],
        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
	input[type="number"]{
		width: 70px;
	}

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;	
	    text-align:center;
	    margin-left:250px;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style></head>
<body>
    <div class="container">
        <h2>Place Order</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Product ID</th>
                    <th>Product Name</th>
                    <th>Expiry Date</th>
                    <th>Price</th>
                    <th>Quantity</th>
                </tr>
                <?php
                session_start(); // Start the session

                // Check if the consumer is logged in
                if (!isset($_SESSION['consumer_id'])) {
                    // Redirect or display an error message if not logged in
                    header("Location: login.php");
                    exit();
                }

                // Get the consumer ID from the session
                $consumer_id = $_SESSION['consumer_id'];

                // Database connection parameters
                $servername = "localhost";
                $username = "root";
                $password = "harshe23673065";
                $dbname = "farm2market";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Fetch products for the logged-in consumer from the addtocart table
                $sql = "SELECT * FROM addtocart WHERE consumerid = $consumer_id";
                $result = $conn->query($sql);

                // Display the products in the form
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["productid"] . "</td>";
                        echo "<td>" . $row["productname"] . "</td>";
                        echo "<td>" . $row["expiry_date"] . "</td>";
                        echo "<td>$" . $row["price"] . "</td>";
                        echo "<td><input type='number' name='quantity[" . $row["id"] . "]' value='1' min='1'></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>No products found for the logged-in consumer</td></tr>";
                }

                // Close the database connection
                $conn->close();
                ?>
            </table>

            <h2>Order Details</h2>
            <label for="delivery_address">Delivery Address:</label>
            <input type="text" name="delivery_address" id="delivery_address" required>

            <label for="contact_number">Contact Number:</label>
            <input type="text" name="contact_number" id="contact_number" required>

            <label for="special_instructions">Special Instructions:</label>
            <textarea name="special_instructions" id="special_instructions"></textarea>

            <input type="submit" name="submit" value="Place Order">
        </form>

        <?php
        // Check if form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Database connection parameters
            $servername = "localhost";
            $username = "root";
            $password = "harshe23673065";
            $dbname = "farm2market";

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Retrieve form data
            $delivery_address = $_POST['delivery_address'];
            $contact_number = $_POST['contact_number'];
            $special_instructions = $_POST['special_instructions'];
            $quantities = $_POST['quantity'];

            // Get the consumer ID from the session
            $consumer_id = $_SESSION['consumer_id'];

            // Insert order into orders table for each product
            foreach ($quantities as $product_id => $quantity) {
                // Validate quantity
                if ($quantity <= 0) {
                    continue; // Skip if quantity is not positive
                }

                // Fetch product details from the database
                $sql = "SELECT * FROM addtocart WHERE id = $product_id AND consumerid = $consumer_id";
                $result = $conn->query($sql);
                $product = $result->fetch_assoc();

                if ($product) {
                    // Calculate total amount
                    $total_amount = $quantity * $product['price'];

                    // Insert order into orders table
                    $sql = "INSERT INTO orders (consumerid, order_date, total_amount, order_status, delivery_address, contact_number, special_instructions, quantity, product_id) 
                            VALUES ($consumer_id, NOW(), $total_amount, 'Pending', '$delivery_address', '$contact_number', '$special_instructions', $quantity, $product_id)";

                    if ($conn->query($sql) === TRUE) {
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                } else {
                    echo "<p>Product not found for Product ID: $product_id</p>";
                }
            }

            // Close connection
            $conn->close();
            echo '<script>alert("Orders have been successfully placed!");';
    	    echo 'window.location.href = "selectproduct.php";</script>';
        }
        ?>
    </div>
</body>
</html>