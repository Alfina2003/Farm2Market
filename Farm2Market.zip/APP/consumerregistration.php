<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farm2Market Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #076f76;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            max-width: 400px;
            padding: 20px;
            background-color: white;
            box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            text-align: center;
        }

        .container h1 {
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        .form-group input[type="text"],
        .form-group input[type="password"],
        .form-group input[type="email"],
        .form-group input[type="tel"],
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .form-group input[type="submit"] {
            background-color: #4caf50;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s;
            align-self: center;
            text-align: center;
            margin-left: 150px;
        }

        .form-group input[type="submit"]:hover {
            background-color: #45a049;
        }

        .form-group small {
            color: #888;
        }
    </style></head>

<body>
    <div class="container">
        <h1>Farm2Market Registration</h1>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Database connection parameters
            $host = "localhost"; // Change this if your MySQL server is hosted elsewhere
            $username = "root"; // Your MySQL username
            $password = "harshe23673065"; // Your MySQL password
            $database = "farm2market"; // Your MySQL database name

            // Create connection
            $conn = new mysqli($host, $username, $password, $database);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Prepare data for insertion
            $name = $_POST['name'];
            $password = $_POST['password'];
            $email = $_POST['email'];
            $contact_number = $_POST['contact_number'];
            $address = $_POST['address'];

            // Insert data into database
            $sql = "INSERT INTO consumerregister (name, password, email, contact_number, address) VALUES ('$name', '$password', '$email', '$contact_number', '$address')";

	    if ($conn->query($sql) === TRUE) {
                echo '<script>alert("Registration successful !");';
    	    	echo 'window.location.href = "consumerlogin.php";</script>';
            } else {
                 echo "<script>alert('Error: " . $sql . "<br>" . $conn->error . "');</script>";
            }

            // Close connection
            $conn->close();
        }
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="contact_country_code">Country Code</label>
                <select id="contact_country_code" name="contact_country_code" required>
                    <option value="+1">+1 (United States)</option>
                    <option value="+44">+44 (United Kingdom)</option>
                    <option value="+91">+91 (India)</option>
                    <!-- Add more country codes as needed -->
                </select>
            </div>
            <div class="form-group">
                <label for="contact_number">Contact Number</label>
                <input type="tel" id="contact_number" name="contact_number" pattern="[0-9]{10}" required>
                
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" rows="4" required></textarea>
            </div>
            <div class="form-group">
                <input type="submit" value="Register">
            </div>
        </form>
    </div>
        </form>
    </div>
</body>

</html>