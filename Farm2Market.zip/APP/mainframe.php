<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Farm2Market - Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Reset default margin and padding */
        body, h1, h2, p, a {
            margin: 0;
            padding: 0;
        }

        /* Box-sizing to include padding and borders in element's total width and height */
        * {
            box-sizing: border-box;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            font-family: 'Arial', sans-serif;
            background-color: #f2f2f2;
            background-image: url('pic.jpg'); /* Add background image */
            background-repeat: repeat;
            background-attachment: fixed; /* Ensure the background image stays fixed */
            position: relative; /* Position the logout button relative to the body */
        }

        .dashboard-container {
            max-width: 400px;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            text-align: center;
            color: #000; /* Set text color to white for better contrast */
            background-color: rgba(255, 255, 255, 0.8); /* Add a semi-transparent background color to the container */
        }

        .dashboard-container h1 {
            font-size: 28px;
            margin-bottom: 20px;
        }

        .button-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .dashboard-button {
            width: 100%;
            padding: 15px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            text-align: center;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dashboard-button:hover {
            background-color: #0056b3;
        }

        /* Logout button styles */
        .logout-button {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 10px;
            background-color: #dc3545;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
            transition: background-color 0.3s;
        }

        .logout-button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <?php
        // Initialize the session
        session_start();
        
        // Check if the user is logged in, if not then redirect them to the login page
        if(!isset($_SESSION["farmer_id"])){
            header("location: first.php");
            exit;
        }

        // Logout logic
        if(isset($_POST["logout"])) {
            // Unset all of the session variables
            $_SESSION = array();
            
            // Destroy the session
            session_destroy();
            
            // Redirect to login page
            header("location: first.php");
            exit;
        }
    ?>
    <form method="post" style="position: absolute; top: 10px; right: 10px;">
        <button type="submit" class="logout-button" name="logout">Logout</button>
    </form>
    <div class="dashboard-container">
        <h1>Welcome to Your Farm2Market Dashboard</h1>
        <div class="button-container">
            <a class="dashboard-button" href="addtoproduct.php">Add Products</a>
            <a class="dashboard-button" href="editproduct.php">Edit Products</a>
            <a class="dashboard-button" href="manageorders.php">Manage Orders</a>
            <a class="dashboard-button" href="viewprofile.php">View Profile</a>
        </div>
    </div>
</body>
</html>
